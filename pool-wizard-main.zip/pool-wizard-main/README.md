Pool Questionnaire — Phase 4 Next.js Project

Phase 4 adds:
- Refurbishment workflow (branching logic) so form adapts for refurb projects
- PDF proposal export (client info, selected photos, 2D preview, BOQ) using jsPDF + html2canvas
- Everything from Phase 3.5 (improved 3D, photo scaling, extended BOQ)

How to run:
1. Upload this ZIP to CodeSandbox (Import -> Upload) OR
2. Unzip locally and run:
   npm install
   npm run dev
Open http://localhost:3000
