Pool Questionnaire — Phase 2 Next.js Project

How to use:
1. Upload this ZIP to CodeSandbox (Import -> Upload) OR
   unzip locally and run:
   - npm install
   - npm run dev
2. Open http://localhost:3000 to view the multi-step wizard.

Phase 2 adds:
- Tailwind CSS (already configured)
- Photo upload & thumbnails (mobile friendly)
- Simple Three.js 3D preview stub (box scaled by pool dimensions)
- Editable BOQ with labour & unit prices
- JSON & CSV export

Notes:
- This is a demo. For production, hook up persistent storage, authentication, and robust media handling.
