
import { useState } from "react";
import { useForm, FormProvider, useWatch } from "react-hook-form";
import dynamic from 'next/dynamic';
import Pool3D from '../components/Pool3D';

function Input({ name, label, type="text", ...rest }) {
  return (
    <label className="block mb-3">
      <div className="font-semibold mb-1">{label}</div>
      <input name={name} type={type} className="w-full border rounded px-3 py-2" {...rest} />
    </label>
  );
}

export default function Home() {
  const methods = useForm({ defaultValues: {} });
  const { control, handleSubmit } = methods;
  const [step, setStep] = useState(0);
  const [photos, setPhotos] = useState([]);

  const length = useWatch({ control, name: "poolLength" }) || 0;
  const width = useWatch({ control, name: "poolWidth" }) || 0;
  const shallow = useWatch({ control, name: "shallowDepth" }) || 0;
  const deep = useWatch({ control, name: "deepDepth" }) || 0;

  const pages = [
    <div key="p1">
      <h2 className="text-xl font-bold mb-3">📅 Project & Client Details</h2>
      <Input name="clientName" label="Client Name" />
      <Input name="contactNumber" label="Contact Number" />
      <Input name="email" label="Email" type="email" />
      <Input name="propertyAddress" label="Property Address / Location" />
      <Input name="salesperson" label="Salesperson / Representative" />
      <Input name="meetingDate" label="Date of Meeting" type="date" />
    </div>,
    <div key="p2">
      <h2 className="text-xl font-bold mb-3">📐 Pool Dimensions & Type</h2>
      <Input name="poolLength" label="Length (m)" type="number" />
      <Input name="poolWidth" label="Width (m)" type="number" />
      <Input name="shallowDepth" label="Shallow end depth (m)" type="number" />
      <Input name="deepDepth" label="Deep end depth (m)" type="number" />
      <label className="block mb-3">
        <div className="font-semibold mb-1">Pool Type</div>
        <select name="poolType" className="w-full border rounded px-3 py-2">
          <option>Skimmer</option>
          <option>Overflow</option>
          <option>Other</option>
        </select>
      </label>
      <Input name="separateSpa" label="Separate Spa / Children's Pool (describe)" />
      <div className="mt-4">
        <h3 className="font-semibold mb-2">🔍 Live 2D Preview</h3>
        <svg width={Math.max(120, length*12+40)} height={Math.max(120, width*12+80)} className="bg-blue-50 rounded p-2">
          <rect x="20" y="20" width={Math.max(10, length*12)} height={Math.max(10, width*12)} fill="#60a5fa" stroke="#1e3a8a" strokeWidth="2" rx="6" />
          <text x="25" y="15" fontSize="12">Length: {length} m</text>
          <text x="10" y={Math.max(10, width*12)/2 + 20} fontSize="12" transform={`rotate(-90, 10, ${Math.max(10, width*12)/2 + 20})`}>Width: {width} m</text>
          <text x="25" y={Math.max(120, width*12)+45} fontSize="12">Depth: {shallow} m - {deep} m</text>
        </svg>
      </div>

      <div className="mt-6">
        <h3 className="font-semibold mb-2">📱 Site Photos</h3>
        <p className="text-sm text-gray-600 mb-2">Use your smartphone to take photos — upload them here to attach to the project.</p>
        <input type="file" accept="image/*" multiple onChange={(e)=> {
          const files = Array.from(e.target.files);
          files.forEach(file => {
            const reader = new FileReader();
            reader.onload = () => {
              setPhotos(prev => [...prev, { name: file.name, data: reader.result }]);
            };
            reader.readAsDataURL(file);
          });
        }} />
        <div className="mt-3 grid grid-cols-3 gap-2">
          {photos.map((p, idx) => (
            <div key={idx} className="border rounded overflow-hidden">
              <img src={p.data} alt={p.name} className="w-full h-24 object-cover" />
              <div className="p-1 text-xs">{p.name}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-6">
        <h3 className="font-semibold mb-2">🧭 Simple 3D Preview (rotating box)</h3>
        <Pool3D length={Number(length)||5} width={Number(width)||3} depth={Number(((Number(shallow)||1)+(Number(deep)||1))/2)} />
      </div>
    </div>,
    <div key="p3">
      <h2 className="text-xl font-bold mb-3">🧱 Structural & Finishes</h2>
      <label className="block mb-3">
        <div className="font-semibold mb-1">Pool Structure</div>
        <select name="structure" className="w-full border rounded px-3 py-2">
          <option>Reinforced Concrete</option>
          <option>Blockwork with Liner</option>
          <option>Fiberglass Shell</option>
          <option>Other</option>
        </select>
      </label>
      <label className="block mb-3">
        <div className="font-semibold mb-1">Internal Finish</div>
        <select name="finish" className="w-full border rounded px-3 py-2">
          <option>Mosaic Tiles</option>
          <option>Render / Plaster</option>
          <option>Liner</option>
          <option>Paint</option>
          <option>Other</option>
        </select>
      </label>
      <Input name="stepsBench" label="Integrated pool steps / bench (describe)" />
    </div>,
    <div key="p4">
      <h2 className="text-xl font-bold mb-3">💧 Filtration, Services & Features</h2>
      <label className="block mb-3"><div className="font-semibold mb-1">Filtration</div><select name="filtration" className="w-full border rounded px-3 py-2"><option>Yes</option><option>No</option><option>Not Sure</option></select></label>
      <Input name="lightingQty" label="Lighting Qty" type="number" />
      <label className="block mb-3"><div className="font-semibold mb-1">Heating</div><select name="heating" className="w-full border rounded px-3 py-2"><option>Yes</option><option>No</option><option>Not Sure</option></select></label>
      <label className="block mb-3"><div className="font-semibold mb-1">Automation</div><select name="automation" className="w-full border rounded px-3 py-2"><option>Yes</option><option>No</option><option>Not Sure</option></select></label>
      <Input name="waterFeatures" label="Water features (describe)" />
      <label className="block mb-3"><div className="font-semibold mb-1">Pool Cover</div><select name="poolCover" className="w-full border rounded px-3 py-2"><option>Manual</option><option>Automatic</option><option>None</option></select></label>
    </div>,
    <div key="p5">
      <h2 className="text-xl font-bold mb-3">🌊 Patio / Surrounding Area</h2>
      <label className="block mb-3"><div className="font-semibold mb-1">Patio Required</div><select name="patioRequired" className="w-full border rounded px-3 py-2"><option>Yes</option><option>No</option></select></label>
      <Input name="patioArea" label="Patio Area (m²)" type="number" />
      <label className="block mb-3"><div className="font-semibold mb-1">Paving Material</div><select name="pavingMaterial" className="w-full border rounded px-3 py-2"><option>Natural Stone</option><option>Porcelain / Ceramic</option><option>Concrete Pavers</option><option>Timber Decking</option><option>Other</option></select></label>
      <label className="block mb-3"><div className="font-semibold mb-1">Drainage</div><select name="drainage" className="w-full border rounded px-3 py-2"><option>Yes</option><option>No</option><option>Not Sure</option></select></label>
    </div>,
    <div key="p6">
      <h2 className="text-xl font-bold mb-3">🏛️ Planning & Permits</h2>
      <label className="block mb-3"><div className="font-semibold mb-1">Planning Permission</div><select name="planning" className="w-full border rounded px-3 py-2"><option>Yes</option><option>No</option><option>Not Sure</option></select></label>
      <label className="block mb-3"><div className="font-semibold mb-1">Help with Permits</div><select name="permitsHelp" className="w-full border rounded px-3 py-2"><option>Yes</option><option>No</option></select></label>
      <label className="block mb-3"><div className="font-semibold mb-1">Site Plan</div><select name="sitePlan" className="w-full border rounded px-3 py-2"><option>Yes</option><option>No</option></select></label>
      <Input name="engineer" label="Registered Engineer / Architect (Name)" />
    </div>,
    <div key="p7">
      <h2 className="text-xl font-bold mb-3">🧱 Ground Conditions & Site Access</h2>
      <label className="block mb-3"><div className="font-semibold mb-1">Known Ground Conditions</div><select name="ground" className="w-full border rounded px-3 py-2"><option>Soil</option><option>Clay</option><option>Rocky / Soft Limestone</option><option>Not Sure</option></select></label>
      <label className="block mb-3"><div className="font-semibold mb-1">Machinery Access</div><select name="access" className="w-full border rounded px-3 py-2"><option>Yes</option><option>No</option><option>Limited</option></select></label>
      <label className="block mb-3"><div className="font-semibold mb-1">Ground Investigation</div><select name="investigation" className="w-full border rounded px-3 py-2"><option>Yes</option><option>No</option></select></label>
      <Input name="buildType" label="New Pool or Renovation (describe)" />
    </div>,
    <div key="p8">
      <h2 className="text-xl font-bold mb-3">🧾 Budget & Timeline</h2>
      <Input name="budget" label="Estimated Budget Range (€)" />
      <Input name="startDate" label="Preferred Start Date" type="date" />
      <Input name="completionDate" label="Target Completion Date" type="date" />
    </div>,
    <div key="p9">
      <h2 className="text-xl font-bold mb-3">📝 Client Notes & Signatures</h2>
      <label className="block mb-3">
        <div className="font-semibold mb-1">Notes</div>
        <textarea name="notes" className="w-full border rounded px-3 py-2" rows="4" />
      </label>
      <Input name="clientSignature" label="Client Signature (type name)" />
      <Input name="salesSignature" label="Salesperson Signature (type name)" />
    </div>,
  ];

  // BOQ Review component inline for simplicity
  const BOQReview = () => {
    const finish = methods.getValues('finish') || 'Mosaic Tiles';
    const patioArea = Number(methods.getValues('patioArea') || 0);
    const avgDepth = ((Number(shallow)||1) + (Number(deep)||1)) / 2;
    const waterVolume = (Number(length)||5) * (Number(width)||3) * avgDepth;
    const excavationVolume = waterVolume * 1.2;
    const floorArea = (Number(length)||5) * (Number(width)||3);
    const wallArea = 2 * ((Number(length)||5) + (Number(width)||3)) * avgDepth;
    const tileArea = floorArea + wallArea * 0.5;
    const copingLength = 2 * ((Number(length)||5) + (Number(width)||3));
    const wallThickness = 0.2; const slabThickness = 0.15;
    const concreteVolume = Math.max(0, copingLength * wallThickness * avgDepth + floorArea * slabThickness);

    const defaultPrices = {
      excavation: 30, concrete: 120, tile: finish.toLowerCase().includes('mosaic') ? 80 : finish.toLowerCase().includes('liner') ? 15 : 45,
      coping:70, excavationLabour:20, tilingLabour:35, concreteLabour:25
    };
    const [prices, setPrices] = useState(defaultPrices);

    const boqItems = [
      { code:'EXC', description:'Excavation (m3)', qty: round(excavationVolume,2), unit:'m3', unitPrice:prices.excavation, total: round(excavationVolume*prices.excavation,2) },
      { code:'EXC-L', description:'Excavation Labour (hrs equiv)', qty: round(excavationVolume*1.5,2), unit:'hr', unitPrice:prices.excavationLabour, total: round(excavationVolume*1.5*prices.excavationLabour,2) },
      { code:'CONC', description:'Concrete (m3)', qty: round(concreteVolume,2), unit:'m3', unitPrice:prices.concrete, total: round(concreteVolume*prices.concrete,2) },
      { code:'CONC-L', description:'Concrete Labour (hrs equiv)', qty: round(concreteVolume*2,2), unit:'hr', unitPrice:prices.concreteLabour, total: round(concreteVolume*2*prices.concreteLabour,2) },
      { code:'TILE', description:'Internal Finish (m2)', qty: round(tileArea,2), unit:'m2', unitPrice:prices.tile, total: round(tileArea*prices.tile,2) },
      { code:'TILE-L', description:'Tiling Labour (m2)', qty: round(tileArea,2), unit:'m2', unitPrice:prices.tilingLabour, total: round(tileArea*prices.tilingLabour,2) },
      { code:'COP', description:'Coping (m)', qty: round(copingLength,2), unit:'m', unitPrice:prices.coping, total: round(copingLength*prices.coping,2) },
    ];
    const subtotal = boqItems.reduce((s,i)=> s + i.total, 0);
    function downloadCSV(){
      const headers = ['Code','Description','Qty','Unit','UnitPrice','Total'];
      const rows = boqItems.map(i=> [i.code,i.description,i.qty,i.unit,i.unitPrice,i.total]);
      const csv = [headers, ...rows].map(r=> r.join(',')).join('\\n');
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'boq.csv'; a.click();
    }
    return (
      <div>
        <h2 className="text-xl font-bold mb-2">🧾 BOQ & Unit Prices</h2>
        <p className="text-sm text-gray-600 mb-2">Edit unit prices and labour rates; totals update in real time.</p>
        <div className="grid grid-cols-2 gap-3 mb-3">
          <div>
            <label className="block text-sm">Excavation €/m3</label>
            <input className="w-full border rounded px-2 py-1" type="number" value={prices.excavation} onChange={e=> setPrices({...prices, excavation: Number(e.target.value)})} />
          </div>
          <div>
            <label className="block text-sm">Concrete €/m3</label>
            <input className="w-full border rounded px-2 py-1" type="number" value={prices.concrete} onChange={e=> setPrices({...prices, concrete: Number(e.target.value)})} />
          </div>
          <div>
            <label className="block text-sm">Tile €/m2</label>
            <input className="w-full border rounded px-2 py-1" type="number" value={prices.tile} onChange={e=> setPrices({...prices, tile: Number(e.target.value)})} />
          </div>
          <div>
            <label className="block text-sm">Coping €/m</label>
            <input className="w-full border rounded px-2 py-1" type="number" value={prices.coping} onChange={e=> setPrices({...prices, coping: Number(e.target.value)})} />
          </div>
          <div>
            <label className="block text-sm">Excavation Labour €/hr</label>
            <input className="w-full border rounded px-2 py-1" type="number" value={prices.excavationLabour} onChange={e=> setPrices({...prices, excavationLabour: Number(e.target.value)})} />
          </div>
          <div>
            <label className="block text-sm">Tiling Labour €/m2</label>
            <input className="w-full border rounded px-2 py-1" type="number" value={prices.tilingLabour} onChange={e=> setPrices({...prices, tilingLabour: Number(e.target.value)})} />
          </div>
        </div>
        <table className="w-full border-collapse border">
          <thead><tr className="bg-gray-100"><th className="p-2">Code</th><th className="p-2">Description</th><th className="p-2">Qty</th><th className="p-2">Unit</th><th className="p-2">Unit €</th><th className="p-2">Total €</th></tr></thead>
          <tbody>
            {boqItems.map(it=> <tr key={it.code}><td className="p-2 border">{it.code}</td><td className="p-2 border">{it.description}</td><td className="p-2 border">{it.qty}</td><td className="p-2 border">{it.unit}</td><td className="p-2 border">{it.unitPrice}</td><td className="p-2 border">{it.total}</td></tr>)}
            <tr className="font-bold"><td colSpan="5" className="p-2 text-right border">Subtotal</td><td className="p-2 border">{round(subtotal,2)}</td></tr>
          </tbody>
        </table>
        <div className="mt-3">
          <button type="button" className="bg-blue-600 text-white px-3 py-2 rounded" onClick={downloadCSV}>Download BOQ CSV</button>
        </div>
      </div>
    );
  };

  function round(n,d=2){ return Math.round((n+Number.EPSILON)*Math.pow(10,d))/Math.pow(10,d); }

  function exportJSON(data){
    const j = JSON.stringify({...data, photos: photos.map(p=>p.name)}, null, 2);
    const blob = new Blob([j], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'pool_questionnaire.json'; a.click();
  }

  return (
    <FormProvider {...methods}>
      <div className="max-w-4xl mx-auto p-6">
        <form onSubmit={handleSubmit(exportJSON)} className="bg-white p-6 rounded shadow">
          <div className="h-2 bg-gray-200 rounded mb-4">
            <div className="h-2 bg-blue-600 rounded" style={{width: `${((step+1)/(pages.length+1))*100}%`}} />
          </div>

          <div className="min-h-[220px]">
            {pages[step]}
          </div>

          <div className="flex justify-between mt-6">
            <div>
              {step>0 && <button type="button" className="mr-2 bg-gray-300 px-3 py-2 rounded" onClick={()=> setStep(s=>s-1)}>Back</button>}
              {step < pages.length-1 && <button type="button" className="bg-blue-600 text-white px-3 py-2 rounded" onClick={()=> setStep(s=>s+1)}>Next</button>}
            </div>
            <div>
              {step === pages.length-1 ? (
                <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded">Export JSON</button>
              ) : null}
            </div>
          </div>

          {step === pages.length && <BOQReview />}
        </form>

        {/* Quick access to BOQ as final step button */}
        <div className="mt-4 text-sm text-gray-600">When you finish signatures, proceed to the final BOQ review by clicking Next until the end.</div>
      </div>
    </FormProvider>
  );
}
