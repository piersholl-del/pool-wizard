export default function Home() {
  return (
    <div style={{padding: 40}}>
      <h1>Pool Wizard App</h1>
      <p>If you see this page on Vercel, the deployment worked! 🎉</p>
      <p>Next step: replace this placeholder with the full Phase 4.2 wizard code.</p>
    </div>
  );
}