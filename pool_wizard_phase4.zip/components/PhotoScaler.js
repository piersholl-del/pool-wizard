import { useRef, useState, useEffect } from 'react';

export default function PhotoScaler({ imageSrc, onScaleComputed }) {
  const canvasRef = useRef();
  const [image, setImage] = useState(null);
  const [points, setPoints] = useState([]);
  const [realLength, setRealLength] = useState('');
  const [scale, setScale] = useState(null);

  useEffect(()=>{
    if(!imageSrc) return;
    const img = new Image();
    img.onload = ()=> setImage(img);
    img.src = imageSrc;
  },[imageSrc]);

  useEffect(()=>{
    const canvas = canvasRef.current;
    if(!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width = Math.min(900, image ? image.width : 900);
    const h = canvas.height = image ? (image.height * (w / image.width)) : 400;
    ctx.clearRect(0,0,w,h);
    if(image){
      ctx.drawImage(image, 0, 0, w, h);
    } else {
      ctx.fillStyle='#eee'; ctx.fillRect(0,0,w,h);
    }
    ctx.strokeStyle = '#ff6464'; ctx.lineWidth = 3;
    points.forEach((p)=>{ ctx.beginPath(); ctx.arc(p.x,p.y,6,0,Math.PI*2); ctx.fillStyle='#ff6464'; ctx.fill(); });
    if(points.length===2){
      ctx.beginPath(); ctx.moveTo(points[0].x, points[0].y); ctx.lineTo(points[1].x, points[1].y); ctx.stroke();
    }
    if(scale && image){
      const poolW = 4; const poolL = 8;
      const pxW = poolL * scale; const pxH = poolW * scale;
      ctx.strokeStyle = '#0b8a5f'; ctx.lineWidth = 2;
      ctx.strokeRect(w - pxW - 20, h - pxH - 20, pxW, pxH);
      ctx.fillStyle = 'rgba(11,138,95,0.08)'; ctx.fillRect(w - pxW - 20, h - pxH - 20, pxW, pxH);
    }
  }, [image, points, scale, imageSrc]);

  function handleCanvasClick(e){
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    if(points.length<2){
      setPoints([...points, {x,y}]);
    } else {
      setPoints([{x,y}]);
      setScale(null);
      setRealLength('');
    }
  }

  function computeScale(){
    if(points.length<2 || !realLength) return;
    const dx = points[1].x - points[0].x; const dy = points[1].y - points[0].y;
    const px = Math.sqrt(dx*dx + dy*dy);
    const meters = parseFloat(realLength);
    if(isNaN(meters) || meters<=0) return;
    const pxPerM = px / meters;
    setScale(pxPerM);
    if(onScaleComputed) onScaleComputed(pxPerM);
  }

  return (
    <div>
      <div className="mb-2 small">Click two points on the photo to create a reference line, then enter the real-world length (meters) and press Compute Scale.</div>
      <canvas ref={canvasRef} onClick={handleCanvasClick} style={{width:'100%',maxWidth:900,border:'1px solid #ddd',cursor:'crosshair'}} />
      <div className="mt-2 flex gap-2">
        <input className="input" placeholder="Reference length in meters" value={realLength} onChange={e=> setRealLength(e.target.value)} />
        <button type="button" className="btn btn-primary" onClick={computeScale}>Compute Scale</button>
        <button type="button" className="btn btn-secondary" onClick={()=>{ setPoints([]); setScale(null); setRealLength(''); }}>Reset</button>
      </div>
      {scale && <div className="mt-2 small">Scale: {Math.round(scale)} px / m</div>}
    </div>
  );
}
