import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import OrbitControls from 'three-orbitcontrols';

export default function Pool3D({ length=5, width=3, depth=1.5, showSteps=true }) {
  const mountRef = useRef();

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xf7fbff);
    const camera = new THREE.PerspectiveCamera(45, mount.clientWidth / mount.clientHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    mount.appendChild(renderer.domElement);

    const light = new THREE.DirectionalLight(0xffffff, 0.9);
    light.position.set(5,10,7);
    scene.add(light);
    const amb = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(amb);

    const sx = Math.max(0.5, length);
    const sy = Math.max(0.2, depth);
    const sz = Math.max(0.5, width);

    const outer = new THREE.BoxGeometry(sx, sy, sz);
    const outerMesh = new THREE.Mesh(outer, new THREE.MeshStandardMaterial({ color: 0x1e40af, roughness:0.4 }));
    outerMesh.position.y = 0;
    scene.add(outerMesh);

    const waterGeom = new THREE.PlaneGeometry(sx-0.1, sz-0.1);
    const waterMat = new THREE.MeshStandardMaterial({ color:0x60a5fa, transparent:true, opacity:0.85 });
    const water = new THREE.Mesh(waterGeom, waterMat);
    water.rotation.x = -Math.PI/2;
    water.position.y = 0.05;
    scene.add(water);

    const copingGeom = new THREE.BoxGeometry(sx+0.1, 0.05, sz+0.1);
    const copingMat = new THREE.MeshStandardMaterial({ color:0xe0d7c6 });
    const coping = new THREE.Mesh(copingGeom, copingMat);
    coping.position.y = sy/2 + 0.025;
    scene.add(coping);

    if(showSteps){
      const stepGeom = new THREE.BoxGeometry(sx*0.3, 0.05, sz*0.2);
      const stepMat = new THREE.MeshStandardMaterial({ color:0xd1d5db });
      const step = new THREE.Mesh(stepGeom, stepMat);
      step.position.set(-sx*0.35, -sy/2 + 0.05, -sz*0.35);
      scene.add(step);
    }

    const controls = new OrbitControls(camera, renderer.domElement);
    camera.position.set(sx*1.5, sy*2.5, sz*2);
    controls.update();

    const animate = function () {
      requestAnimationFrame(animate);
      outerMesh.rotation.y += 0.0015;
      coping.rotation.y += 0.0015;
      water.rotation.y += 0.0008;
      renderer.render(scene, camera);
    };
    animate();

    function onResize() {
      renderer.setSize(mount.clientWidth, mount.clientHeight);
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
    }
    window.addEventListener('resize', onResize);

    return () => {
      window.removeEventListener('resize', onResize);
      mount.removeChild(renderer.domElement);
      renderer.dispose();
    };
  }, [length, width, depth, showSteps]);

  return <div ref={mountRef} style={{width:'100%', height:360}} />;
}
