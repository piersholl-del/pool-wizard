Pool Questionnaire — Phase 3 Next.js Project

Phase 3 adds:
- Extended BOQ catalog (pumps, filters, lighting, cover, automation, permits)
- VAT and contingency percentage inputs with totals
- Everything from Phase 2 (photo upload, 2D preview, 3D stub)

How to run:
1. Upload to CodeSandbox (Import -> Upload) OR
2. Unzip locally and run:
   npm install
   npm run dev
Open http://localhost:3000
