import { useEffect, useRef } from 'react';
import * as THREE from 'three';

export default function Pool3D({ length=5, width=3, depth=1.5 }) {
  const mountRef = useRef();

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, mount.clientWidth / mount.clientHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    mount.appendChild(renderer.domElement);

    const light = new THREE.DirectionalLight(0xffffff, 0.9);
    light.position.set(5,10,7);
    scene.add(light);
    const amb = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(amb);

    const sx = Math.max(0.1, length);
    const sy = Math.max(0.1, depth);
    const sz = Math.max(0.1, width);
    const geometry = new THREE.BoxGeometry(sx, sy, sz);
    const material = new THREE.MeshStandardMaterial({ color: 0x60a5fa, roughness: 0.6, metalness: 0.1, opacity:0.9, transparent:true });
    const cube = new THREE.Mesh(geometry, material);
    scene.add(cube);

    camera.position.set(sx*1.5, sy*2.5, sz*2);
    camera.lookAt(cube.position);

    const animate = function () {
      requestAnimationFrame(animate);
      cube.rotation.y += 0.005;
      renderer.render(scene, camera);
    };
    animate();

    function onResize() {
      renderer.setSize(mount.clientWidth, mount.clientHeight);
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
    }
    window.addEventListener('resize', onResize);

    return () => {
      window.removeEventListener('resize', onResize);
      mount.removeChild(renderer.domElement);
      renderer.dispose();
    };
  }, [length, width, depth]);

  return <div ref={mountRef} style={{width:'100%', height:300}} />;
}
