
import { useState } from "react";
import { useForm, FormProvider, useWatch } from "react-hook-form";
import Pool3D from "../components/Pool3D";

function Input({ name, label, type="text", ...rest }) {
  return (
    <label className="field">
      <div className="font-semibold mb-1">{label}</div>
      <input name={name} type={type} className="input" {...rest} />
    </label>
  );
}

export default function Home() {
  const methods = useForm({ defaultValues: {} });
  const { control, handleSubmit } = methods;
  const [step, setStep] = useState(0);
  const [photos, setPhotos] = useState([]);

  const length = useWatch({ control, name: "poolLength" }) || 0;
  const width = useWatch({ control, name: "poolWidth" }) || 0;
  const shallow = useWatch({ control, name: "shallowDepth" }) || 0;
  const deep = useWatch({ control, name: "deepDepth" }) || 0;

  const pages = [ /* steps omitted for brevity, similar to previous phase */ ];

  // We'll render steps inline for simplicity (similar to Phase 2)
  const Step1 = (
    <div>
      <h2 className="text-xl font-bold mb-3">📅 Project & Client Details</h2>
      <Input name="clientName" label="Client Name" />
      <Input name="contactNumber" label="Contact Number" />
      <Input name="email" label="Email" type="email" />
      <Input name="propertyAddress" label="Property Address / Location" />
      <Input name="salesperson" label="Salesperson / Representative" />
      <Input name="meetingDate" label="Date of Meeting" type="date" />
    </div>
  );

  const Step2 = (
    <div>
      <h2 className="text-xl font-bold mb-3">📐 Pool Dimensions & Type</h2>
      <Input name="poolLength" label="Length (m)" type="number" />
      <Input name="poolWidth" label="Width (m)" type="number" />
      <Input name="shallowDepth" label="Shallow end depth (m)" type="number" />
      <Input name="deepDepth" label="Deep end depth (m)" type="number" />
      <label className="field">
        <div className="font-semibold mb-1">Pool Type</div>
        <select name="poolType" className="input">
          <option>Skimmer</option><option>Overflow</option><option>Other</option>
        </select>
      </label>
      <div className="mt-4">
        <h3 className="font-semibold mb-2">🔍 Live 2D Preview</h3>
        <svg width={Math.max(120, length*12+40)} height={Math.max(120, width*12+80)} className="bg-blue-50 rounded p-2">
          <rect x="20" y="20" width={Math.max(10, length*12)} height={Math.max(10, width*12)} fill="#60a5fa" stroke="#1e3a8a" strokeWidth="2" rx="6" />
          <text x="25" y="15" fontSize="12">Length: {length} m</text>
          <text x="10" y={Math.max(10, width*12)/2 + 20} fontSize="12" transform={`rotate(-90, 10, ${Math.max(10, width*12)/2 + 20})`}>Width: {width} m</text>
          <text x="25" y={Math.max(120, width*12)+45} fontSize="12">Depth: {shallow} m - {deep} m</text>
        </svg>
      </div>
      <div className="mt-6">
        <h3 className="font-semibold mb-2">📱 Site Photos</h3>
        <input type="file" accept="image/*" multiple onChange={(e)=> {
          const files = Array.from(e.target.files);
          files.forEach(file => {
            const reader = new FileReader();
            reader.onload = () => {
              setPhotos(prev => [...prev, { name: file.name, data: reader.result }]);
            };
            reader.readAsDataURL(file);
          });
        }} />
        <div className="mt-3 grid grid-cols-3 gap-2">
          {photos.map((p, idx) => (
            <div key={idx} className="border rounded overflow-hidden">
              <img src={p.data} alt={p.name} className="w-full h-24 object-cover" />
              <div className="p-1 text-xs">{p.name}</div>
            </div>
          ))}
        </div>
      </div>
      <div className="mt-6">
        <h3 className="font-semibold mb-2">🧭 Simple 3D Preview (rotating box)</h3>
        <Pool3D length={Number(length)||5} width={Number(width)||3} depth={Number(((Number(shallow)||1)+(Number(deep)||1))/2)} />
      </div>
    </div>
  );

  const Step3 = (
    <div>
      <h2 className="text-xl font-bold mb-3">🧱 Structural & Finishes</h2>
      <label className="block mb-3">
        <div className="font-semibold mb-1">Pool Structure</div>
        <select name="structure" className="input">
          <option>Reinforced Concrete</option><option>Blockwork with Liner</option><option>Fiberglass Shell</option><option>Other</option>
        </select>
      </label>
      <label className="block mb-3">
        <div className="font-semibold mb-1">Internal Finish</div>
        <select name="finish" className="input">
          <option>Mosaic Tiles</option><option>Render / Plaster</option><option>Liner</option><option>Paint</option><option>Other</option>
        </select>
      </label>
      <Input name="stepsBench" label="Integrated pool steps / bench (describe)" />
    </div>
  );

  const Step4 = (
    <div>
      <h2 className="text-xl font-bold mb-3">💧 Filtration, Services & Features</h2>
      <label className="block mb-3"><div className="font-semibold mb-1">Filtration</div><select name="filtration" className="input"><option>Yes</option><option>No</option><option>Not Sure</option></select></label>
      <Input name="lightingQty" label="Lighting Qty" type="number" />
      <label className="block mb-3"><div className="font-semibold mb-1">Heating</div><select name="heating" className="input"><option>Yes</option><option>No</option><option>Not Sure</option></select></label>
      <label className="block mb-3"><div className="font-semibold mb-1">Automation</div><select name="automation" className="input"><option>Yes</option><option>No</option><option>Not Sure</option></select></label>
      <Input name="waterFeatures" label="Water features (describe)" />
      <label className="block mb-3"><div className="font-semibold mb-1">Pool Cover</div><select name="poolCover" className="input"><option>Manual</option><option>Automatic</option><option>None</option></select></label>
    </div>
  );

  const Step5 = (
    <div>
      <h2 className="text-xl font-bold mb-3">🌊 Patio / Surrounding Area</h2>
      <label className="block mb-3"><div className="font-semibold mb-1">Patio Required</div><select name="patioRequired" className="input"><option>Yes</option><option>No</option></select></label>
      <Input name="patioArea" label="Patio Area (m²)" type="number" />
      <label className="block mb-3"><div className="font-semibold mb-1">Paving Material</div><select name="pavingMaterial" className="input"><option>Natural Stone</option><option>Porcelain / Ceramic</option><option>Concrete Pavers</option><option>Timber Decking</option><option>Other</option></select></label>
      <label className="block mb-3"><div className="font-semibold mb-1">Drainage</div><select name="drainage" className="input"><option>Yes</option><option>No</option><option>Not Sure</option></select></label>
    </div>
  );

  const Step6 = (
    <div>
      <h2 className="text-xl font-bold mb-3">🏛️ Planning & Permits</h2>
      <label className="block mb-3"><div className="font-semibold mb-1">Planning Permission</div><select name="planning" className="input"><option>Yes</option><option>No</option><option>Not Sure</option></select></label>
      <label className="block mb-3"><div className="font-semibold mb-1">Help with Permits</div><select name="permitsHelp" className="input"><option>Yes</option><option>No</option></select></label>
      <label className="block mb-3"><div className="font-semibold mb-1">Site Plan</div><select name="sitePlan" className="input"><option>Yes</option><option>No</option></select></label>
      <Input name="engineer" label="Registered Engineer / Architect (Name)" />
    </div>
  );

  const Step7 = (
    <div>
      <h2 className="text-xl font-bold mb-3">🧱 Ground Conditions & Site Access</h2>
      <label className="block mb-3"><div className="font-semibold mb-1">Known Ground Conditions</div><select name="ground" className="input"><option>Soil</option><option>Clay</option><option>Rocky / Soft Limestone</option><option>Not Sure</option></select></label>
      <label className="block mb-3"><div className="font-semibold mb-1">Machinery Access</div><select name="access" className="input"><option>Yes</option><option>No</option><option>Limited Access</option></select></label>
      <label className="block mb-3"><div className="font-semibold mb-1">Ground Investigation</div><select name="investigation" className="input"><option>Yes</option><option>No</option></select></label>
      <Input name="buildType" label="New Pool or Renovation (describe)" />
    </div>
  );

  const Step8 = (
    <div>
      <h2 className="text-xl font-bold mb-3">🧾 Budget & Timeline</h2>
      <Input name="budget" label="Estimated Budget Range (€)" />
      <Input name="startDate" label="Preferred Start Date" type="date" />
      <Input name="completionDate" label="Target Completion Date" type="date" />
    </div>
  );

  const Step9 = (
    <div>
      <h2 className="text-xl font-bold mb-3">📝 Client Notes & Signatures</h2>
      <label className="field"><div className="font-semibold mb-1">Notes</div><textarea name="notes" className="input" rows="4" /></label>
      <Input name="clientSignature" label="Client Signature (type name)" />
      <Input name="salesSignature" label="Salesperson Signature (type name)" />
    </div>
  );

  const pagesArr = [Step1, Step2, Step3, Step4, Step5, Step6, Step7, Step8, Step9];

  // Extended BOQ component
  const BOQReview = () => {
    const finish = methods.getValues('finish') || 'Mosaic Tiles';
    const patioArea = Number(methods.getValues('patioArea') || 0);
    const avgDepth = ((Number(shallow)||1) + (Number(deep)||1)) / 2;
    const waterVolume = (Number(length)||5) * (Number(width)||3) * avgDepth;
    const excavationVolume = waterVolume * 1.2;
    const floorArea = (Number(length)||5) * (Number(width)||3);
    const wallArea = 2 * ((Number(length)||5) + (Number(width)||3)) * avgDepth;
    const tileArea = floorArea + wallArea * 0.5;
    const copingLength = 2 * ((Number(length)||5) + (Number(width)||3));
    const wallThickness = 0.2; const slabThickness = 0.15;
    const concreteVolume = Math.max(0, copingLength * wallThickness * avgDepth + floorArea * slabThickness);

    // Extended catalog default unit prices
    const defaultPrices = {
      excavation: 30, concrete: 120, tile: finish.toLowerCase().includes('mosaic') ? 80 : finish.toLowerCase().includes('liner') ? 15 : 45,
      coping:70, excavationLabour:20, tilingLabour:35, concreteLabour:25,
      pump: 800, filter: 450, heater: 1200, automation: 600, lightingUnit: 60, cover: 1500, electrical: 80
    };

    const [prices, setPrices] = useState(defaultPrices);
    const [vat, setVat] = useState(19); // default VAT %
    const [contingency, setContingency] = useState(10); // default contingency %

    const boqItems = [
      { code:'EXC', description:'Excavation (m3)', qty: round(excavationVolume,2), unit:'m3', unitPrice:prices.excavation, total: round(excavationVolume*prices.excavation,2) },
      { code:'EXC-L', description:'Excavation Labour (hrs equiv)', qty: round(excavationVolume*1.5,2), unit:'hr', unitPrice:prices.excavationLabour, total: round(excavationVolume*1.5*prices.excavationLabour,2) },
      { code:'CONC', description:'Concrete (m3)', qty: round(concreteVolume,2), unit:'m3', unitPrice:prices.concrete, total: round(concreteVolume*prices.concrete,2) },
      { code:'CONC-L', description:'Concrete Labour (hrs equiv)', qty: round(concreteVolume*2,2), unit:'hr', unitPrice:prices.concreteLabour, total: round(concreteVolume*2*prices.concreteLabour,2) },
      { code:'TILE', description:'Internal Finish (m2)', qty: round(tileArea,2), unit:'m2', unitPrice:prices.tile, total: round(tileArea*prices.tile,2) },
      { code:'TILE-L', description:'Tiling Labour (m2)', qty: round(tileArea,2), unit:'m2', unitPrice:prices.tilingLabour, total: round(tileArea*prices.tilingLabour,2) },
      { code:'PUMP', description:'Pump & Filtration (unit)', qty: 1, unit:'unit', unitPrice:prices.pump, total: prices.pump },
      { code:'FILTER', description:'Filter (unit)', qty:1, unit:'unit', unitPrice:prices.filter, total:prices.filter },
      { code:'HEAT', description:'Heater (unit)', qty: (methods.getValues('heating')==='Yes')?1:0, unit:'unit', unitPrice:prices.heater, total: ((methods.getValues('heating')==='Yes')?prices.heater:0) },
      { code:'AUTO', description:'Automation (unit)', qty: (methods.getValues('automation')==='Yes')?1:0, unit:'unit', unitPrice:prices.automation, total: ((methods.getValues('automation')==='Yes')?prices.automation:0) },
      { code:'LIGHT', description:'Underwater Lighting (unit)', qty: Number(methods.getValues('lightingQty')||0), unit:'unit', unitPrice:prices.lightingUnit, total: round((Number(methods.getValues('lightingQty')||0))*prices.lightingUnit,2) },
      { code:'COVER', description:'Pool Cover', qty: (methods.getValues('poolCover')==='Automatic')?1:((methods.getValues('poolCover')==='Manual')?1:0), unit:'unit', unitPrice:prices.cover, total: ((methods.getValues('poolCover')==='None')?0:prices.cover) },
      { code:'ELEC', description:'Electrical (allowance)', qty: round( (floorArea + copingLength)*0.1,2), unit:'hrs', unitPrice:prices.electrical, total: round(((floorArea + copingLength)*0.1)*prices.electrical,2) },
      { code:'COP', description:'Coping (m)', qty: round(copingLength,2), unit:'m', unitPrice:prices.coping, total: round(copingLength*prices.coping,2) },
    ];

    const materialsSubtotal = boqItems.reduce((s,i)=> s + i.total, 0);
    const vatAmount = materialsSubtotal * (vat/100);
    const contingencyAmount = materialsSubtotal * (contingency/100);
    const grandTotal = materialsSubtotal + vatAmount + contingencyAmount;

    function downloadCSV(){
      const headers = ['Code','Description','Qty','Unit','UnitPrice','Total'];
      const rows = boqItems.map(i=> [i.code,i.description,i.qty,i.unit,i.unitPrice,i.total]);
      const csv = [headers, ...rows].map(r=> r.join(',')).join('\n');
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'boq_extended.csv'; a.click();
    }

    return (
      <div>
        <h2 className="text-xl font-bold mb-2">🧾 Extended BOQ & Pricing</h2>
        <p className="small mb-3">Edit prices, VAT % and contingency to reflect your local rates.</p>

        <div className="grid grid-cols-2 gap-3 mb-3">
          {Object.keys(prices).map(key => (
            <div key={key}>
              <label className="block text-sm">{key}</label>
              <input className="input" type="number" value={prices[key]} onChange={e=> setPrices({...prices, [key]: Number(e.target.value)})} />
            </div>
          ))}
          <div>
            <label className="block text-sm">VAT %</label>
            <input className="input" type="number" value={vat} onChange={e=> setVat(Number(e.target.value))} />
          </div>
          <div>
            <label className="block text-sm">Contingency %</label>
            <input className="input" type="number" value={contingency} onChange={e=> setContingency(Number(e.target.value))} />
          </div>
        </div>

        <table className="boq-table">
          <thead><tr><th>Code</th><th>Description</th><th>Qty</th><th>Unit</th><th>Unit €</th><th>Total €</th></tr></thead>
          <tbody>
            {boqItems.map(it=> <tr key={it.code}><td className="p-2 border">{it.code}</td><td className="p-2 border">{it.description}</td><td className="p-2 border">{it.qty}</td><td className="p-2 border">{it.unit}</td><td className="p-2 border">{it.unitPrice}</td><td className="p-2 border">{it.total}</td></tr>)}
            <tr className="font-bold"><td colSpan="5" className="p-2 text-right border">Subtotal</td><td className="p-2 border">{round(materialsSubtotal,2)}</td></tr>
            <tr className="font-bold"><td colSpan="5" className="p-2 text-right border">VAT ({vat}%)</td><td className="p-2 border">{round(vatAmount,2)}</td></tr>
            <tr className="font-bold"><td colSpan="5" className="p-2 text-right border">Contingency ({contingency}%)</td><td className="p-2 border">{round(contingencyAmount,2)}</td></tr>
            <tr className="font-bold"><td colSpan="5" className="p-2 text-right border">Grand Total</td><td className="p-2 border">{round(grandTotal,2)}</td></tr>
          </tbody>
        </table>

        <div className="mt-3">
          <button type="button" className="btn btn-primary" onClick={downloadCSV}>Download Extended BOQ CSV</button>
        </div>
      </div>
    );
  };

  function round(n,d=2){ return Math.round((n+Number.EPSILON)*Math.pow(10,d))/Math.pow(10,d); }

  function exportJSON(data){
    const j = JSON.stringify({...data, photos: photos.map(p=>p.name)}, null, 2);
    const blob = new Blob([j], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'pool_questionnaire_phase3.json'; a.click();
  }

  return (
    <FormProvider {...methods}>
      <div className="container">
        <form onSubmit={handleSubmit(exportJSON)} className="card">
          <div className="h-2 bg-gray-200 rounded mb-4">
            <div className="h-2 bg-blue-600 rounded" style={{width: `${((step+1)/(pagesArr.length+1))*100}%`}} />
          </div>

          <div className="min-h-[240px]">
            {pagesArr[step]}
          </div>

          <div className="flex justify-between mt-6">
            <div>
              {step>0 && <button type="button" className="btn btn-secondary" onClick={()=> setStep(s=>s-1)}>Back</button>}
              {step < pagesArr.length-1 && <button type="button" className="btn btn-primary" onClick={()=> setStep(s=>s+1)}>Next</button>}
            </div>
            <div>
              {step === pagesArr.length-1 ? (
                <button type="submit" className="btn btn-primary">Export JSON</button>
              ) : null}
            </div>
          </div>

          {step === pagesArr.length && <BOQReview />}
        </form>
      </div>
    </FormProvider>
  );
}
