export default function Home() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Pool Wizard Phase 4.2</h1>
      <p>This is a placeholder. The full wizard code should be placed here.</p>
    </div>
  );
}
