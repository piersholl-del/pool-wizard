# Pool Wizard (Phase 4.2)

This is the cleaned repo version for deployment on Vercel.

## Run locally
```bash
npm install
npm run dev
```

## Deploy on Vercel
1. Push this repo to GitHub
2. Import into Vercel
3. Deploy (Next.js auto-detected)
